﻿// Template1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Windows.h>
#include "include\GL\GL.H"
#include "include\GL\GLU.H"
#include "include\GL\glut.h"
#include "include\GL\Glaux.h"
#include <iostream>
#include <cmath>
#include <ctime>
#include <iostream>
#define PI 3.14

class Texturable
{
public:
	static GLuint LoadTexture(const char* filename, GLuint texture)
	{
		int width, height, size;
		char* data;
		FILE* file;

		fopen_s(&file, filename, "rb");
		if (file == nullptr) return 0;

		fseek(file, 18, SEEK_CUR);
		fread(&width, sizeof(int), 1, file);
		fread(&height, sizeof(int), 1, file);
		size = width * height * 3;

		fseek(file, 28, SEEK_CUR);
		data = (char *)malloc(size);
		fread(data, size, 1, file);
		fclose(file);

		for (long i = 0; i < size; i += 3)
		{
			std::swap(data[i], data[i + 2]);
		}

		glBindTexture(GL_TEXTURE_2D, texture);

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);

		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		gluBuild2DMipmaps(GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, data);

		free(data);

		return texture;
	}
};

class Planet
{
public:
	float radius;
	float x;
	float y;
	float speed;

	Planet() {}

	Planet(float radius, float x, float y, float speed) {
		this->radius = radius;
		this->x = x;
		this->y = y;
		this->speed = speed;
	}
};

GLuint texture[10];
float zoom = -90;
int movement = 1;
int changeCamera = 3;
GLuint planets[11];
GLuint orbits = 0;
Planet planetsConst[9];

void Planets(void)
{
	const double t = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
	double a = t; // * 6.0;

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// zmiana kamery 
	if (changeCamera == 0) {
		gluLookAt(0.0, zoom, 0.00001,	//punkt oka
			0.0, 0.0, 0.0,			//odniesienie środka
			0.0, 1.0, 0.0);			//up vector
	}
	if (changeCamera == 1) {
		gluLookAt(0.0, 0.0, zoom,
			0.0, 0.0, 0.0, 
			0.0, 1.0, 0.0);
	}
	if (changeCamera == 2) {
		gluLookAt(0.0, zoom, -0.00001,
			0.0, 0.0, 0.0, 
			0.0, 1.0, 0.0);
	}
	if (changeCamera == 3)
	{
		glTranslated(0, 0, zoom);
	}
	if (changeCamera == 4)
	{
		glTranslated(0, 0, zoom);
	}

	glRotated(-55, 1, 0, 0); // co by było widać nie z rzutu poziomego lub pionowego

	glCallList(orbits);

	for (int i = 0; i < 9; i++)
	{
		glPushMatrix();
		glTranslated(0, -planetsConst[i].y, 0);

		if (i != 0 && movement == 1)
		{
			// ruch planet po orbitach
			glTranslatef((planetsConst[i].x * cos(2.0 * 3.14 * a * planetsConst[i].speed / 100)), (planetsConst[i].y + planetsConst[i].y * sin(2.0 * 3.14 * a * planetsConst[i].speed / 100)), 0);
		}

		// bez tego planety startują ustawione na jednej linii prostopadłej do słońca
		glRotated((i == 0 ? 30 : -20) * a, 0, 0, 1);
		glCallList(planets[i]);

		glPopMatrix();
	}
}

void Display(void)
{
	glDrawBuffer(GL_BACK);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	Planets();
	glutSwapBuffers();
	glEnd();
	glFlush();
}

void Prepare()
{
	GLUquadric *qobj = gluNewQuadric();
	for (int i = 0; i < 9; i++)
	{
		// przypinanie textur planetom
		glPushMatrix();
		planets[i] = glGenLists(1);
		glNewList(planets[i], GL_COMPILE);
		glEnable(GL_TEXTURE_2D);

		gluQuadricTexture(qobj, GL_TRUE);
		glBindTexture(GL_TEXTURE_2D, texture[i]);
		gluSphere(qobj, planetsConst[i].radius, 50, 50);

		glDisable(GL_TEXTURE_2D);

		glEndList();
		glPopMatrix();	
	}

	orbits = glGenLists(10);
	glNewList(orbits, GL_COMPILE);
	for (int i = 1; i < 9; i++)
	{
		glPushMatrix();

		glTranslated(0, -planetsConst[i].y, 0);
		glBegin(GL_LINE_LOOP);

		for (int j = 0; j < 101; j++) {
			// tworzenie orbity ze wzoru na obwód okręgu, który przechodzi przez "środek planety"
			glVertex2f(planetsConst[i].x * cos(2.0 * 3.14 * j / 100), planetsConst[i].y + planetsConst[i].y * sin(2.0 * 3.14 * j / 100));
		}

		glEnd();
		glPopMatrix();
	}
	glEndList();
}

void MyInit(void)
{
	glEnable(GL_COLOR_MATERIAL);

	glGenTextures(10, texture);

	texture[0] = Texturable::LoadTexture("sun.bmp", 0);
	texture[1] = Texturable::LoadTexture("mercury.bmp", 1);
	texture[2] = Texturable::LoadTexture("venus.bmp", 2);
	texture[3] = Texturable::LoadTexture("earth.bmp", 3);
	texture[4] = Texturable::LoadTexture("mars.bmp", 4);
	texture[5] = Texturable::LoadTexture("jupiter.bmp", 5);
	texture[6] = Texturable::LoadTexture("saturn.bmp", 6);
	texture[7] = Texturable::LoadTexture("uranus.bmp", 7);
	texture[8] = Texturable::LoadTexture("neptune.bmp", 8);
	texture[9] = Texturable::LoadTexture("moon.bmp", 9);

	planetsConst[0] = Planet(1.5, 0, 0, 0);							//sun
	planetsConst[1] = Planet(0.05, 2.3, 1.9, 3.7);					//mercury
	planetsConst[2] = Planet(0.1, 2.8, 2.8, 2.5);					//venus
	planetsConst[3] = Planet(0.2, 3.6, 3.4, 1.9);					//earth
	planetsConst[4] = Planet(0.07, 4.5, 4.2, 2.4);					//mars
	planetsConst[5] = Planet(0.5, 8.2, 7, 1.3);						//jupiter
	planetsConst[6] = Planet(0.3, 12.2, 11, 0.9);					//saturn
	planetsConst[7] = Planet(0.2, 22, 20, 0.6);						//uranus
	planetsConst[8] = Planet(0.2, 37, 34, 0.5);						//neptuno

	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);

	Prepare();
}

void Reshape(GLsizei width, GLsizei heigth)
{
	if (heigth == 0) { 
		heigth = 1;
	}

	glViewport(0, 0, width, heigth);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(16, (GLfloat)width / (GLfloat)heigth, 1, 800);
	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}

static void Idle(void)
{
	glutPostRedisplay();
}

void Keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 'a':
		changeCamera = 0;
		break;
	case 's':
		changeCamera = 1;
		break;
	case 'd':
		changeCamera = 2;
		break;
	case '+':
		changeCamera = 3;
		zoom++;
		break;
	case '-':
		changeCamera = 4;
		zoom--;
		break;
	}
}

int main(int argc, char **argv) {

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1200, 720);
	glutInitWindowPosition(10, 10);
	glutCreateWindow("Układ słoneczny");

	MyInit();

	glutDisplayFunc(Display);
	glutReshapeFunc(Reshape);
	glutIdleFunc(Idle);
	glutKeyboardFunc(Keyboard);

	glutMainLoop();
}