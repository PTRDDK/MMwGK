// Template1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Windows.h>
#include "include\GL\GL.H"
#include "include\GL\GLU.H"
#include "include\GL\glut.h"
#include <vector>

class Triangle
{
	GLfloat colors[6][4] = {
		{ (GLfloat)0,(GLfloat)0,(GLfloat)1,(GLfloat)1 },		// blue
		{ (GLfloat)0,(GLfloat)1,(GLfloat)0,(GLfloat)1 },		// green
		{ (GLfloat)1,(GLfloat)0,(GLfloat)0,(GLfloat)1 },		// red
		{ (GLfloat)1,(GLfloat)0.5,(GLfloat)0,(GLfloat)1 },		// orange
		{ (GLfloat)1,(GLfloat)1,(GLfloat)0,(GLfloat)1 },		// yellow
		{ (GLfloat)0.6,(GLfloat)0,(GLfloat)1,(GLfloat)1 }		// purple
	};

	GLfloat* a;
	GLfloat* b;
	GLfloat* c;
	GLfloat* color;

public:
	Triangle(std::vector<GLfloat> xyz, int color)
	{
		this->a = new GLfloat[2]{ xyz[0], xyz[1] };
		this->b = new GLfloat[2]{ xyz[0] + xyz[2], xyz[1] };
		this->c = new GLfloat[2]{ xyz[0], xyz[1] + xyz[2] };
		this->color = colors[color];
	}

	void Draw() const
	{
		glBegin(GL_POLYGON);
		glColor4fv(this->color);
		glVertex2fv(this->a);
		glVertex2fv(this->b);
		glVertex2fv(this->c);
		glEnd();
	}
};

GLfloat posX = 100, posY = 100, posZ = 0, rotation = 0, deviation = 0;
int direction = 1;
boolean stop_rotate = false;

void MyKeyboard(unsigned char key, int x, int y)
{
	GLfloat move_unit = 0.01, rotate_unit = 10;
	switch (key)
	{
	case 'a':
		if (stop_rotate)
		{
			deviation += move_unit;
			rotation += 0;
		}
		else if (!stop_rotate)
		{
			deviation += move_unit * direction;
			rotation += rotate_unit;
		}
		break;
	case 'd':
		if (stop_rotate)
		{
			deviation -= move_unit;
			rotation -= 0;
		}
		else if (!stop_rotate)
		{
			deviation -= move_unit * direction;
			rotation -= rotate_unit;
		}
		break;
	case 'c':
		deviation = 0;
		rotation = 0;
		break;
	case 's':
		if (stop_rotate)
		{
			stop_rotate = false;
		}
		else if (!stop_rotate)
		{
			stop_rotate = true;
		}
		break;
	}

	if (deviation > 1 || deviation < 0)
	{
		direction *= -1;
	}
	glutPostRedisplay();
}

void MyDisplay(void)
{
	GLfloat a = 10, a1 = 3, a2 = 90;
	int trianglesRows = 3, trianglesCols = 3, translateConst = 4;
	std::vector<std::vector<GLfloat>> triangles;
	

	glLoadIdentity();
	glClear(GL_COLOR_BUFFER_BIT);

	for (int i = 0; i < trianglesRows; i++)
	{
		for (int j = 0; j < trianglesCols - i; j++)
		{
			triangles.push_back({ a * i, a * j, a });
		}
	}

	for (int i = 0; i < translateConst; i++)
	{
		for (int j = 0; j < triangles.size(); j++)
		{
			GLfloat rot = j % 2 == 0 || j == 5 ? -1 : 1;
			glPushMatrix();

			glTranslatef(posX, posY, posZ);
			glRotatef(rot * (rotation / a1 + (i * a2)), 0, 0, 1);

			glTranslatef((triangles.at(j)[0] * 2 * triangles.at(j)[2]) / 3 + deviation, (2 * triangles.at(j)[1] + triangles.at(j)[2]) / 3 * deviation, posZ);
			glTranslatef(triangles.at(j)[0] + translateConst, triangles.at(j)[1] + translateConst, posZ);
			glRotatef(rot * (-rotation), 0, 0, 1);
			glTranslatef(-triangles.at(j)[0] - translateConst, -triangles.at(j)[1] - translateConst, posZ);
			Triangle(triangles.at(j), j).Draw();
			glPopMatrix();
		}
	}

	glEnd();
	glFlush();
}

void MyInit(void)
{
	glClearColor(0, 0, 0, 0);
	glViewport(0, 0, 300, 300);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, posX * 2, 0, posY * 2);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(700, 700);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Triangles");

	MyInit();
	glutDisplayFunc(MyDisplay);
	glutKeyboardFunc(MyKeyboard);

	glutMainLoop();
	return 0;
}