#pragma once
class Triangle
{
public:
	Triangle();
	~Triangle();
};

